import React from "react";
import "./App.css";
import ContentRating from "./Components/ContentRating";

function App() {
  return (
    <div className="App">
      <h1 style={{ textAlign: "center" }}>Content Rating App</h1>
      <ContentRating />
    </div>
  );
}

export default App;
